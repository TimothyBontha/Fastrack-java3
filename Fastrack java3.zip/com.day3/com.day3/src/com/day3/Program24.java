
package com.day3;

public class Program24 {
	
	public void display() {
		System.out.println("I am method from class A");
	}

}
