
package com.day3;

public class Program4{
	
	public static void main(String[] args) {
		Car2Parametrized c2 = new Car2Parametrized("closed"	, "on", "seated", 10);
		
		System.out.println(c2.run());
	}

}
