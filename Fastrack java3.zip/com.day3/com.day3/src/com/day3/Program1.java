
package com.day3;

public class Program1 {
	
	public Car() {
		
		//Code block constructor general
	}

}
