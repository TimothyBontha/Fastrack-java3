
package com.day3;

public class Program11 {
	
	private String name="john";
	private int age=25;
	private String gender="Male";
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	public String getGender() {
		return gender;
	}
	
	public static void main(String[] args) {
		program11 e2 = new Program11();
		
		
		System.out.println(e2.getAge());
		System.out.println(e2.getName());
		System.out.println(e2.getGender());
	
	}

}
