
package com.day3;

public class Program33{
	
	public static void main(String[] args) {
		Program32 m1 = new Program32();
		m1.display();
		
		System.out.println("\n");
		
		m1.display('#');
	}

}
