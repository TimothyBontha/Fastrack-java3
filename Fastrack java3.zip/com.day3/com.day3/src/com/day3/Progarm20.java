
package com.day3;

public class Program20 extends Program19 implements Program18{
	
	
	String language = "Java";

	  // implement method of interface
	  public void connectServer() {
	    System.out.println(language + " can be used as backend language.");
	  }

	  public static void main(String[] args) {

	    // create object of Language class
		  Program20 java = new Program20();

	    java.connectServer();
	 // call the inherited method of Frontend class
	    java.responsive(java.language);
	  }

}
