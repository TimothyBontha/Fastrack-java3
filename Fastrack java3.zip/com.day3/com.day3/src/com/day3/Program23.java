
package com.day3;

public class Program23 extends Program21{
	
	String getCodinglanguage() {
		return "Java";
	}

}
