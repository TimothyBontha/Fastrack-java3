
package com.day3;

public class Program31 extends Program29 {
	
	@Override
	  public void displayInfo() {
	    System.out.println("Java Programming Language");
	  }

}
