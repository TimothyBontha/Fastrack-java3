
package com.day3;

public class Program29 {
	
	public void displayInfo() {
	    System.out.println("Common English Language");
	  }

}
