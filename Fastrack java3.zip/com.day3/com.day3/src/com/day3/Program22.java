
package com.day3;

public class Program22 extends Program23{
	
	int getLineofCode() {
		return 20;
	}
	
	public static void main(String[] args) {
		Program22 mp3 = new Program22();
		System.out.println("I am "+mp3.getName()+" and I code in " + mp3.getCodinglanguage()+" . This Program has" + mp3.getLineofCode()+" lines");
	}

}
