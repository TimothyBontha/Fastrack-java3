
package com.day3;

public class Program28 {
	
	public static void main(String[] args) {
		Program25 b1 = new Program25();
		Program26 c1 = new Program26();
		Program27 d1 = new Program27();
		
		b1.display();
		c1.display();
		d1.display();
	}

}
