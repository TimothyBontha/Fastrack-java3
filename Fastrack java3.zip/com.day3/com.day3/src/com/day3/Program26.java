package com.day3;

public class Program26 extends Program24{
	
	 public void show() {
		 System.out.println(" I am a method from class C");
	 }

}
