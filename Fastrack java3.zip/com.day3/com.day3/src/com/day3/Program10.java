
package com.day3;

public class Program10 {
	
	public String name="john";
	public int age=25;
	public String gender="Male";

}


