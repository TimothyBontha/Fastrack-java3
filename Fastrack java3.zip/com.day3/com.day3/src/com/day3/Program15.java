
package com.day3;

public class Program15 {
	
	public static void main(String[] args) {
	    Program14 e4 = new Program14();
		e4.setAge(25);
		e4.setGender("Male");
		e4.setName("John");
		
		System.out.println(e4.getAge());
		System.out.println(e4.getGender());
		System.out.println(e4.getName());
		
	}

}
