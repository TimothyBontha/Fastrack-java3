
package com.day3;

public class Program2 {
	
	private String doors;
	private String engine;
	private String driver;
	private int speed;
	
	public Program2Default() {
		doors = "closed";
		engine = "on";
		driver= "seated";
		speed = 10;
	}
	
	public String run() {
		if(doors.equals("closed") && engine.equals("on")&& driver.equals("seated") 
				&& speed >0) {
			return "car is running";
		}
		else{
			return "car is not running";
		}
	}

}
