
package com.day3;

public class Program21 {
	
	String getName() {
		return "progrramerBay";
	}

}
