
package com.day3;

public class Program16 {
	
	public void display() {
		System.out.println("I am a method from class A");
	}

}
