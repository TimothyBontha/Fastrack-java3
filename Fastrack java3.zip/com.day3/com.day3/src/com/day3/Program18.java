package com.day3;

public interface Program18 {
	
	//abstract method
	public void connectServer() ;

}
