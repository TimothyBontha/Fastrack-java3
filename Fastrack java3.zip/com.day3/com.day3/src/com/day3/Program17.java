
package com.day3;

public class Program17 extends Program16{
	
	public void print() {
		
		System.out.println("I am a method from class B");
	}
	
	public static void main(String[] args) {
		
		Program17 obj = new Program17();
		obj.display();
		obj.print();
		
	}

}
