
package com.day3;

public class Program30{
	
	public static void main(String[] args) {
		
		Program31 p1 = new Program31();
		p1.displayInfo();
		
		Program29 p2 = new Program29();
		p2.displayInfo();
	}

}	