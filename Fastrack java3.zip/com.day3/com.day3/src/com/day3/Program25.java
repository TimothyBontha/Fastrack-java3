
package com.day3;

public class Program25 extends Program24 {
	
	public void print() {
		System.out.println("I am a method from class B");
	}

}
