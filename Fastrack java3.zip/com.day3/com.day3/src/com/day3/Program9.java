
package com.day3;

public class Program9 extends Program8{
	
	@Override
	public void eat() {
		System.out.println("Eats veg");
	}

}
