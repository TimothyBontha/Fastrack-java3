
package com.day3;

public class Program6 {
	
	public static void main(String[] args) {
		Program8 john = new Program9();
		john.speak();
		john.eat();
		System.out.println("=======================");
		Program8 mia = new Program7();
		mia.speak();
		mia.eat();
	}

}
