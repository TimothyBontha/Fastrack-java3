
package com.day3;

public class Program7 extends Program8 {
	

	@Override
	public void eat() {
		System.out.println("Eats Nonveg");
	}

}
