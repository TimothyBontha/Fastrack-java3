
package com.day3;

public abstract class Program8 {
	
	public void speak() {
		System.out.println("Share his/her thougths");
	}
	
	public abstract void eat();

}
